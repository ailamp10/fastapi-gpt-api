from fastapi import FastAPI
from pydantic import BaseModel
from typing import Dict

app = FastAPI()

class MemoIn(BaseModel):
    tekst: str

class MemoSamenvatting(BaseModel):
    onderzoek: str
    herstel: str
    evaluatie: str

@app.post("/verwerk_memo", response_model=MemoSamenvatting)
def verwerk_memo(data: MemoIn):
    # Placeholder logica - simulatie samenvatting
    return {
        "onderzoek": "Geen informatie beschikbaar",
        "herstel": "Geen informatie beschikbaar",
        "evaluatie": "Geen informatie beschikbaar"
    }
